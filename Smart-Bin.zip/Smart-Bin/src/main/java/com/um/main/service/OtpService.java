package com.um.main.service;

public interface OtpService 
{
    public void sendOtpEmail(String toEmail, String otp);
}
