package com.um.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.um.main.entity.Details;
import com.um.main.repo.DetailsRepo;
import java.time.LocalDate;
import java.util.List;

@Service
public class DetailsServiceImpl implements DetailsService
{
    @Autowired
    private DetailsRepo dr;
    
    @Override
    public boolean addTempUser(Details detail)
    {
        try
        {
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean addDetail(Details detail) 
    {
        try
        {
            detail.setDate(LocalDate.now());
            dr.save(detail);
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
    @Override
    public long getCount() 
    {
        return dr.count();
    }
    
    @Override
    public List<Details> fetch2()
    {
        try
        {
            return dr.findAll();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public boolean deleteRows(List<Details> dt)
    {
        try
        {
            long count= getCount();
            if(count>=20)
            {
                for(int i=0; i<4; i++)
                {
                    Integer id= dt.get(i).getId();
                    dr.deleteById(id);
                }
            }
            return true;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
    }
}
