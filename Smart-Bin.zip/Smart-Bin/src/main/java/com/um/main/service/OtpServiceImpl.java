package com.um.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class OtpServiceImpl implements OtpService
{
    @Autowired 
    private JavaMailSender jms;
    
    @Override
    public void sendOtpEmail(String toEmail, String otp)
    {
        
        SimpleMailMessage message= new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Your OTP Code: ");
        message.setText("Your OTP is: "+otp);
        jms.send(message);
    }
}
