package com.um.main.entity;

public class DTO 
{
    private Details objDetail= new Details();
    private OTP objOtp= new OTP();
    
    public Details getObjDetail() {
        return objDetail;
    }
    public void setObjDetail(Details objDetail) {
        this.objDetail = objDetail;
    }
    public OTP getObjOtp() {
        return objOtp;
    }
    public void setObjOtp(OTP objOtp) {
        this.objOtp = objOtp;
    }
    
}
