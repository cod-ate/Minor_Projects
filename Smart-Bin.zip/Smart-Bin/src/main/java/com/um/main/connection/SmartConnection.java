package com.um.main.connection;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.um.main.entity.*;
import com.um.main.service.DetailsService;
import com.um.main.service.OtpService;

import jakarta.servlet.http.HttpSession;

@Controller
public class SmartConnection
{
    @Autowired
    private DetailsService ds;
    @Autowired
    private OtpService os;
    
    @GetMapping("/")
    public String getBinPage(Model model)
    {
        model.addAttribute("dto", new DTO());
        return "Bin-Details";
    }
    @PostMapping("/detailsForm")
    public String fillBinForm(@ModelAttribute("dto") DTO dto, HttpSession session)
    {
        if(dto.getObjDetail()==null)
        {
            System.out.println("dto.getObjDetail() is null");
            return "Bin-Details";
        }
        boolean status= ds.addTempUser(dto.getObjDetail());
        if(status)
        {
            String ranOtp= generateOtp(dto.getObjDetail());
            System.out.println("Otp: "+ranOtp);
            session.setAttribute("sessionCode", ranOtp);
            session.setAttribute("tempUser", dto.getObjDetail());
//            if(ranOtp.equals("-1"))
//            {
//                session.removeAttribute("tempUser");
//                session.removeAttribute("sessionCode");
//                return "Bin-Details";
//            }
            return "OTP_th";
        }
        return "Bin-Details";
    }
    
    @GetMapping("/otpPage")
    public String getOtpPage(Model model)
    {
        model.addAttribute("dto", new DTO());
        return "OTP_th";
    }
    @PostMapping("/otpForm")
    public String fillOtpForm(@ModelAttribute("dto") DTO dto, HttpSession session, Model model)
    {
        String sessionOtp= (String) session.getAttribute("sessionCode");
//        
        Details detail= (Details) session.getAttribute("tempUser");
//        
        if(detail!=null)
        {
//            Details detail= (Details) session.getAttribute("tempUser");
            if(sessionOtp!=null && sessionOtp.equals(dto.getObjOtp().getOtp()))
            {
                boolean status= ds.addDetail(detail);
                if(status)
                {
                    session.removeAttribute("tempUser");
                    session.removeAttribute("sessionCode");
                    model.addAttribute("successMsg", "Details sent Successfully!!");
                    fetchRows(detail);
                    return "output";
                }
            }
            else
            {
                session.removeAttribute("sessionCode");
                System.out.println("detailObjValue: "+detail.getEmail());
                String ranOtp= generateOtp(detail);
                System.out.println("line: 91, Otp: "+ranOtp);
                session.setAttribute("sessionCode", ranOtp);
                if(ranOtp.equals("-1"))
                {
                    System.out.println("hohoho, line: 95");
                    session.removeAttribute("sessionCode");
                    return "Bin-Details";
                }  
                System.out.println("line: 99");
                model.addAttribute("wrongOtp", "Invalid Otp!!");
                return "OTP_th";
            }
        }
        return "Bin-Details";
    }
    
    
    public String generateOtp(Details detail)
    {
        if(detail.getEmail()==null)
        {
            System.out.println("Email is null at generateOtp()");
            return "-1";
        }
        Random ra= new Random();
        String ranOtp= "" + (ra.nextInt(1000,10000));
        os.sendOtpEmail(detail.getEmail(), ranOtp);
        return ranOtp;
    }
    
    public void fetchRows(Details detail)
    {
        if(detail==null)
            return;
        try 
        {
            ds.deleteRows(ds.fetch2());
        } 
        catch(Exception e) 
        {
            e.printStackTrace();
        }
    }

    
    
    
//    private int callGenOtp= 0;
//    
//    @Autowired
//    private DetailsService ds;
//    
//    @GetMapping("/")
//    public String home(Model model)
//    {
//        model.addAttribute("detail", new Details());
//        return "Bin-Details";
//    }
//    
//    @PostMapping("/detailsForm")
//    public String getDetails(@ModelAttribute("details") Details detail, Model model)
//    {        
//        callGenOtp= generateOtp(detail);
//        return "OTP";
//    }
//    
//    
//    @GetMapping("/otpForm")
//    public String getOtpPage(Model model)
//    {
//        model.addAttribute("objOtp", new OTP());
//        return "OTP";
//    }
//    
//    @PostMapping("/otpForm")
//    public String fillOtp(@ModelAttribute("objOtp") OTP objOtp, Model model, @ModelAttribute("detail") Details detail)
//    {
//        if(callGenOtp == objOtp.getOtp())
//        {
//            boolean status= ds.addDetail(detail);
//            if(status)
//            {
//                model.addAttribute("successMsg", "Details sent Successfully!!");
//                fetchRows(detail);
//                return "output";
//            }
//            model.addAttribute("errorMsg", "Failed to send Details!!");
//            return "output";
//        }
//        
//        return "wrongOtp";
//    }
//    public void fetchRows(Details detail)
//    {
//        try
//        {
//            ds.deleteRows(ds.fetch2());
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//        }
//    }
//    
//    public int generateOtp(Details detail)
//    {
//        Random ra= new Random();
//        int otp= ra.nextInt(1000,10000);
//        String userEmail= detail.getEmail();
//        ds.sendOtpEmail(userEmail, otp);
//        return otp;
//    }
}


