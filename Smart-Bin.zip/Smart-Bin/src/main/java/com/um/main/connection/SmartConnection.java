package com.um.main.connection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.um.main.entity.Details;
import com.um.main.service.DetailsService;

@Controller
public class SmartConnection
{
    @Autowired
    private DetailsService ds;
    
    @GetMapping("/")
    public String home(Model model)
    {
        model.addAttribute("detail", new Details());
        return "Bin-Details";
    }
    
    @PostMapping("/detailsForm")
    public String getDetails(@ModelAttribute("details") Details detail, Model model)
    {
        boolean status= ds.addDetail(detail);
        if(status)
        {
            model.addAttribute("successMsg", "Details sent Successfully!!");
            fetchRows(detail);
            return "output";
        }
        model.addAttribute("errorMsg", "Failed to send Details!!");
        return "output";
    }
    public void fetchRows(Details detail)
    {
        try
        {
            ds.deleteRows(ds.fetch2());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
