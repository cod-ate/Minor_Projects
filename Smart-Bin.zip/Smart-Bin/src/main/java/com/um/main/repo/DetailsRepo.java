package com.um.main.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.um.main.entity.Details;

public interface DetailsRepo extends JpaRepository<Details, Integer>
{

}
