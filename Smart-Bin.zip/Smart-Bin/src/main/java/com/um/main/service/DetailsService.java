package com.um.main.service;

import java.util.List;

import com.um.main.entity.Details;

public interface DetailsService 
{
    public boolean addDetail(Details detail);
    public boolean deleteRows(List<Details> dt);
    public long getCount();
    public List<Details> fetch2();
}
