package in.sp.main;
import in.sp.resources.SpringConfigFile;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.DuplicateKeyException;
import java.util.*;
public class App 
{
    public static void main( String[] args )
    {
    	Work work= new Work();
    	work.crud();
    	System.out.println("Go to Database!!");
    }
}
class Work 
{
	static ApplicationContext context= new AnnotationConfigApplicationContext(SpringConfigFile.class);
	static JdbcTemplate jdbcTemplate= context.getBean(JdbcTemplate.class);
	static Scanner sc= new Scanner(System.in);
	public void crud()
	{
		while(true)
        {
			int n= -1;
        	try
        	{
        		System.out.print("Press:\n '1' to insert,\n '2' to update,\n '3' to delete,\n '0' to exit. --> ");
                n= sc.nextInt();
        	}
        	catch(InputMismatchException e)
			{
				System.out.println("Error!!");
				sc.nextLine();
			}
            if(n==0)
            {
            	System.out.println("OVER!!");
            	break;
            }
        	switch(n)
        	{
        	case 1:
        		insert();
            	break;
        	case 2:
        		update();
            	break;
        	case 3:
        		delete();
            	break;
            default:
            	if(n!=-1)
            		System.out.println("Wrong input!!");
        	}
        }
	}
	private void insert()
	{
			try
			{
				sc.nextLine();
				System.out.print("Enter first name: ");
				String newFName= sc.next();
				System.out.print("Enter last name: ");
				String newLName= sc.next();
				System.out.print("Enter emp id: ");
				int newId= sc.nextInt();
				System.out.print("Enter department: ");
				String newDepartment= sc.next();
				System.out.print("Enter salary: ");
				int newSalary= sc.nextInt();
				String insert_sql_query= "INSERT INTO employee VALUES(?,?,?,?,?)";
		    	int count= jdbcTemplate.update(insert_sql_query, newFName,newLName, newId, newDepartment, newSalary);
		    	if(count>0)
		    		System.out.println("Success");
		    	else	
		    		System.out.println("Fail");
			}
			catch(InputMismatchException e)
			{
				System.out.println("Error!!");
				sc.nextLine();
			}
			catch(DuplicateKeyException e) 
			{
		        System.out.println("Error: Employee ID already exists. Please use a unique ID.");
		    } 
	}
	private void update()
	{
		try
		{
			System.out.print("Enter emp id: ");
			int id= sc.nextInt();
			System.out.print("Update first name: ");
			String upFName= sc.next();
			System.out.print("Update last name: ");
			String upLName= sc.next();
			System.out.print("Update salary: ");
			int upSalary= sc.nextInt();    		
			String update_sql_query= "UPDATE employee SET First_Name=?, Last_Name=?, salary=? WHERE empId=?";
	    	int count= jdbcTemplate.update(update_sql_query, upFName,upLName, upSalary, id);
	    	if(count>0)
	    		System.out.println("Success");
	    	else	
	    		System.out.println("Fail:- Employee ID does not exist.");
		}
		catch(InputMismatchException e)
		{
			System.out.println("Error!!");
			sc.nextLine();
		}
	}
	private void delete()
	{
		try
		{
			System.out.print("Enter emp id: ");
			int id= sc.nextInt();
			String delete_sql_qry= "DELETE FROM employee WHERE empId=?";
			int count= jdbcTemplate.update(delete_sql_qry, id);
	    	if(count>0)
	    		System.out.println("Success");
	    	else
	    		System.out.println("Fail:- Employee ID does not exist.");
		}
		catch(InputMismatchException e)
		{
			System.out.println("Error!!");
			sc.nextLine();
		}
	}
}