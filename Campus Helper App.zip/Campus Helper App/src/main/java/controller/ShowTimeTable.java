package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import connection.DbConnection;
import model.TimeTable;
@WebServlet("/show_Time_Table")
public class ShowTimeTable extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		try {
            Connection con = DbConnection.getConnection();

            String select_query = "select * from timetable";  
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(select_query);

            if (rs.next()) 
            {
                TimeTable tt = new TimeTable();
                tt.setMp1(rs.getString(1));
                tt.setMp2(rs.getString(2));
                tt.setWp1(rs.getString(3));
                tt.setWp2(rs.getString(4));
                tt.setFp1(rs.getString(5));
                tt.setFp2(rs.getString(6));
                
                HttpSession session= req.getSession();
                session.setAttribute("session_tt", tt);
                RequestDispatcher rd = req.getRequestDispatcher("/displayTimeTable.jsp");
                rd.forward(req, resp);
            } else {
                resp.getWriter().println("<h3>No timetable found in DB!</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}
