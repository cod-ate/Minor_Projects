package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import connection.DbConnection;
@WebServlet("/reg_Admin")
public class RegisterAdmin extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String myName= req.getParameter("name1");
		String myEmail= req.getParameter("email1");
		String myPass= req.getParameter("pass1");
		String myDgn= req.getParameter("dgn1");
		
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		
		try
		{
			Connection con= DbConnection.getConnection();
			String insert_query= "insert into admin values(?,?,?,?)";
			PreparedStatement ps= con.prepareStatement(insert_query);
			ps.setString(1, myName);
			ps.setString(2, myEmail);
			ps.setString(3, myPass);
			ps.setString(4, myDgn);
			int count= ps.executeUpdate();
			if(count>0)
			{
				write.println("<h3 style='color:green;'>Registered Successfully</h3>");
				RequestDispatcher rd= req.getRequestDispatcher("/loginAdmin.html");
				rd.include(req, resp);
			}
			else
			{
				write.println("<h3 style='color:red;'>Registration Failed</h3>");
				
				RequestDispatcher rd= req.getRequestDispatcher("/registerAdmin.html");
				rd.include(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
