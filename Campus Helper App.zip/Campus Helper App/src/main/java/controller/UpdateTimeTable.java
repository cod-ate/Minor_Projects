package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import connection.DbConnection;
import model.TimeTable;
@WebServlet("/update_Time_Table")
public class UpdateTimeTable extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String mon_P1= req.getParameter("m1");
		String mon_P2= req.getParameter("m2");
		String wed_P1= req.getParameter("w1");
		String wed_P2= req.getParameter("w2");
		String fri_P1= req.getParameter("f1");
		String fri_P2= req.getParameter("f2");
		
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		
		try
		{
			Connection con= DbConnection.getConnection();
			String oldMon_P1="", oldMon_P2="", oldWed_P1="", oldWed_P2="", oldFri_P1="", oldFri_P2="";
			
			String select_query = "select * FROM timetable";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(select_query);
            TimeTable oldTT= new TimeTable();
            if(rs.next()) 
            {   
                oldTT.setMp1(rs.getString(1));
                oldTT.setMp2(rs.getString(2));
                oldTT.setWp1(rs.getString(3));
                oldTT.setWp2(rs.getString(4));
                oldTT.setFp1(rs.getString(5));
                oldTT.setFp2(rs.getString(6));
            }
            
			String update_query= "update timetable set Monday_P1=?, Monday_P2=?, Wednesday_P1=?, Wednesday_P2=?, Friday_P1=?, Friday_P2=?";
			PreparedStatement ps = con.prepareStatement(update_query);
			if(mon_P1==null || mon_P1.trim().isEmpty())
				mon_P1= oldTT.getMp1();
			if(mon_P2==null || mon_P2.trim().isEmpty())
				mon_P2= oldTT.getMp2();
			if(wed_P1==null || wed_P1.trim().isEmpty())
				wed_P1= oldTT.getWp1();
			if(wed_P2==null || wed_P2.trim().isEmpty())
				wed_P2= oldTT.getWp2();
			if(fri_P1==null || fri_P1.trim().isEmpty())
				fri_P1= oldTT.getFp1();
			if(fri_P2==null || fri_P2.trim().isEmpty())
				fri_P2= oldTT.getFp2();
			
            ps.setString(1, mon_P1);
            ps.setString(2, mon_P2);
            ps.setString(3, wed_P1);
            ps.setString(4, wed_P2);
            ps.setString(5, fri_P1);
            ps.setString(6, fri_P2);

            int count = ps.executeUpdate();
            if(count>0)
			{
				TimeTable tt= new TimeTable();
				tt.setMp1(mon_P1);
				tt.setMp2(mon_P2);
				tt.setWp1(wed_P1);
				tt.setWp2(wed_P2);
				tt.setFp1(fri_P1);
				tt.setFp2(fri_P2);
				HttpSession session= req.getSession();
				
				session.setAttribute("session_tt", tt);
			    RequestDispatcher rd = req.getRequestDispatcher("/displayTimeTable.jsp");
			    rd.forward(req, resp);
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("/updateTimeTable.html");
			    rd.forward(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
