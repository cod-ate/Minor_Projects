package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import connection.DbConnection;
import java.time.*;
@WebServlet("/found")
public class FoundUpdate extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String ownerMob= req.getParameter("contact1");
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		try
		{
			Connection con= DbConnection.getConnection();
			String update_query = "update search set Status=?, Date=? where Contact=?";
			PreparedStatement ps= con.prepareStatement(update_query);
			String date= ""+LocalDate.now();
			ps.setString(1, "found");
			ps.setString(2, date);
			ps.setString(3, ownerMob);
			int count= ps.executeUpdate();
			if(count>0)
			{
//				write.println("<h3 style='color: green;'>Updated Successfully!!</h3>");
				write.println("<div id='success-msg' style='position:fixed; top:20px; left:50%; "
						+ "transform:translateX(-50%); background-color:#4CAF50; color:white; "
						+ "padding:15px 30px; border-radius:8px; font-size:16px; z-index:1000;'>"
						+ "Updated Successfully!</div>");
			    write.println("<script>");
			    write.println("setTimeout(function(){ document.getElementById('success-msg').style."
			    		+ "display='none'; }, 2000);");
			    write.println("</script>");
				RequestDispatcher rd= req.getRequestDispatcher("/found.html");
				rd.include(req, resp);
			}
			else
			{
				RequestDispatcher rd= req.getRequestDispatcher("/adminProfile.jsp");
				rd.forward(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
