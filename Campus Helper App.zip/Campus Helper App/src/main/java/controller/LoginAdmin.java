package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import connection.DbConnection;
import model.Admin;

@WebServlet("/log_Admin")
public class LoginAdmin extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String myEmail= req.getParameter("email1");
		String myPass= req.getParameter("pass1");
		
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		try
		{
			Connection con= DbConnection.getConnection();
			String select_query= "select * from admin where Email=? and Password=?";
			PreparedStatement ps= con.prepareStatement(select_query);
			ps.setString(1, myEmail);
			ps.setString(2, myPass);
			ResultSet rs= ps.executeQuery();
			if(rs.next())
			{
				Admin admin= new Admin();
				admin.setName(rs.getString("name"));
				admin.setEmail(rs.getString("email"));
				admin.setDesignation(rs.getString("designation"));
				HttpSession session= req.getSession();
				session.setAttribute("session_admin", admin);
				RequestDispatcher rd= req.getRequestDispatcher("/adminProfile.jsp");
				rd.forward(req,  resp);
			}
			else
			{
				write.println("<h3 style='color:red;'>Wrong Email/Password</h3>");
				
				RequestDispatcher rd= req.getRequestDispatcher("/loginAdmin.html");
				rd.include(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
