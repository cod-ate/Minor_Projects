package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import connection.DbConnection;
import model.Notice;
@WebServlet("/show_Notice")
public class ShowNotice extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		try {
            Connection con = DbConnection.getConnection();

            String select_query = "select * from notice";  
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(select_query);
            ArrayList<Notice> note= new ArrayList<>();
            
            while(rs.next())
            {
            	Notice notice = new Notice();
            	notice.setNewNotice(rs.getString(1));   
            	note.add(notice);
            }
            if(!note.isEmpty()) 
            {
                HttpSession session= req.getSession();
                session.setAttribute("session_note", note);
                RequestDispatcher rd = req.getRequestDispatcher("/showNotice.jsp");
                rd.forward(req, resp);
            } 
            else 
            {
                resp.getWriter().println("<h3>No notice found in DB!</h3>");
            }
        } 
		catch (Exception e)
		{
            e.printStackTrace();
        }
	}
}
