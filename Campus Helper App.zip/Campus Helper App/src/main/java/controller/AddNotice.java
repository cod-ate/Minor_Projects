package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import connection.DbConnection;
import model.Notice;

@WebServlet("/add_Notice")
public class AddNotice extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String myNotice= req.getParameter("notice1");
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		try
		{
			Connection con= DbConnection.getConnection();
			String insert_query= "insert into notice values(?)";
			PreparedStatement ps= con.prepareStatement(insert_query);
			ps.setString(1, myNotice);
			int count= ps.executeUpdate();
			if(count>0)
			{
//				Notice notice= new Notice();
//				notice.setNewNotice(myNotice);
//				HttpSession session= req.getSession();
//				session.setAttribute("session_notice", notice);
				write.println("<h3 style='color: green;'>Notice added Successfully!!</h3>");
				RequestDispatcher rd= req.getRequestDispatcher("/addNotice.html");
				rd.include(req, resp);
			}
			else
			{
				RequestDispatcher rd= req.getRequestDispatcher("/adminProfile.jsp");
				rd.forward(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
