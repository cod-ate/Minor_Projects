package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import connection.DbConnection;
import model.Notice;
import java.time.*;
import java.util.*;

@WebServlet("/add_Notice")
public class AddNotice extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String myNotice= req.getParameter("notice1");
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		try
		{
			Connection con= DbConnection.getConnection();
			String insert_query= "insert into notice values(?,?)";
			PreparedStatement ps= con.prepareStatement(insert_query);
			String date= ""+LocalDate.now();
			ps.setString(1, myNotice);
			ps.setString(2, date);
			int count= ps.executeUpdate();
			if(count>0)
			{
				Notice notice= new Notice();
				notice.setNewNotice(myNotice);
				notice.setDate(date);
				HttpSession session= req.getSession();
				session.setAttribute("session_notice", notice);
//				write.println("<h3 style='color: green;'>Notice added Successfully!!</h3>");
				write.println("<div id='success-msg' style='position:fixed; top:20px; left:50%; "
						+ "transform:translateX(-50%); background-color:#4CAF50; color:white; "
						+ "padding:15px 30px; border-radius:8px; font-size:16px; z-index:1000;'>"
						+ "Notice added successfully!</div>");
			    write.println("<script>");
			    write.println("setTimeout(function(){ document.getElementById('success-msg').style."
			    		+ "display='none'; }, 2000);");
			    write.println("</script>");
				RequestDispatcher rd= req.getRequestDispatcher("/addNotice.html");
				rd.include(req, resp);
			}
			else
			{
				RequestDispatcher rd= req.getRequestDispatcher("/adminProfile.jsp");
				rd.forward(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
