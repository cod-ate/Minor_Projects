package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import connection.DbConnection;
import model.LostFound;
@WebServlet("/show_lostFound")
public class ShowLostFound extends HttpServlet
{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		try {
            Connection con = DbConnection.getConnection();

            String select_query = "select * from search";  
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(select_query);
            ArrayList<LostFound> lostFound= new ArrayList<>();
            
            while(rs.next())
            {
            	LostFound lf = new LostFound();
            	lf.setName(rs.getString(1));
            	lf.setMobile(rs.getString(2));
            	lf.setDescription(rs.getString(3));
            	lf.setStatus(rs.getString(4));
            	lf.setDate(rs.getString(5));
            	lostFound.add(lf);
            }
            if(!lostFound.isEmpty()) 
            {
                HttpSession session= req.getSession();
                session.setAttribute("session_lf", lostFound);
                RequestDispatcher rd = req.getRequestDispatcher("/showLostFound.jsp");
                rd.forward(req, resp);
            } 
            else 
            {
                resp.getWriter().println("<h3>No data found in DB!</h3>");
            }
        } 
		catch (Exception e)
		{
            e.printStackTrace();
        }
	}
}
