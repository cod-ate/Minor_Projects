package controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import connection.DbConnection;
import model.TimeTable;
@WebServlet("/create_Time_Table")
public class CreateTimeTable extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String mon_P1= req.getParameter("m1");
		String mon_P2= req.getParameter("m2");
		String wed_P1= req.getParameter("w1");
		String wed_P2= req.getParameter("w2");
		String fri_P1= req.getParameter("f1");
		String fri_P2= req.getParameter("f2");
		
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		
		try
		{
			Connection con= DbConnection.getConnection();
			String insert_query= "insert into timetable values(?,?,?,?,?,?)";
			PreparedStatement ps1= con.prepareStatement(insert_query);
			ps1.setString(1, mon_P1);
			ps1.setString(2, mon_P2);
			ps1.setString(3, wed_P1);
			ps1.setString(4, wed_P2);
			ps1.setString(5, fri_P1);
			ps1.setString(6, fri_P2);
			int count= ps1.executeUpdate();
			if(count>0)
			{
				TimeTable tt= new TimeTable();
				tt.setMp1(mon_P1);
				tt.setMp2(mon_P2);
				tt.setWp1(wed_P1);
				tt.setWp2(wed_P2);
				tt.setFp1(fri_P1);
				tt.setFp2(fri_P2);
				HttpSession session= req.getSession();
				
				session.setAttribute("session_tt", tt);
			    RequestDispatcher rd = req.getRequestDispatcher("/displayTimeTable.jsp");
			    rd.forward(req, resp);
			}
			else
			{
				RequestDispatcher rd = req.getRequestDispatcher("/createTimeTable.html");
			    rd.forward(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
