package controller;

import java.io.*;
import java.sql.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

import connection.DbConnection;

import javax.servlet.*;
@WebServlet("/reg_User")
public class RegisterUser extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException
	{
		String myName= req.getParameter("name1");
		String myEmail= req.getParameter("email1");
		String myPass= req.getParameter("pass1");
		String myYear= req.getParameter("year1");
		String myCourse= req.getParameter("course1");
		
		PrintWriter write= resp.getWriter();
		resp.setContentType("text/html");
		
		try
		{
			Connection con= DbConnection.getConnection();
			String insert_query= "insert into student values(?,?,?,?,?)";
			PreparedStatement ps= con.prepareStatement(insert_query);
			ps.setString(1, myName);
			ps.setString(2, myEmail);
			ps.setString(3, myPass);
			ps.setString(4, myYear);
			ps.setString(5, myCourse);
			int count= ps.executeUpdate();
			if(count>0)
			{
				write.println("<h3 style='color:green;'>Registered Successfully</h3>");
				RequestDispatcher rd= req.getRequestDispatcher("/loginUser.html");
				rd.include(req, resp);
			}
			else
			{
				write.println("<h3 style='color:red;'>Registration Failed</h3>");
				
				RequestDispatcher rd= req.getRequestDispatcher("/registerUser.html");
				rd.include(req, resp);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
