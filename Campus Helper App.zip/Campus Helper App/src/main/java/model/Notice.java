package model;

public class Notice 
{
	private String newNotice;

	public String getNewNotice() {
		return newNotice;
	}

	public void setNewNotice(String newNotice) {
		this.newNotice = newNotice;
	}
	
}
