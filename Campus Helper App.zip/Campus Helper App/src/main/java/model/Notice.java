package model;
public class Notice 
{
	private String newNotice;
	private String date;
	
	public String getNewNotice() {
		return newNotice;
	}

	public void setNewNotice(String newNotice) {
		this.newNotice = newNotice;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	
}
