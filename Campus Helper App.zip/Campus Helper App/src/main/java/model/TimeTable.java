package model;

public class TimeTable 
{
	private String mp1, mp2, wp1, wp2, fp1, fp2;

	public String getMp1() {
		return mp1;
	}

	public void setMp1(String mp1) {
		this.mp1 = mp1;
	}

	public String getMp2() {
		return mp2;
	}

	public void setMp2(String mp2) {
		this.mp2 = mp2;
	}

	public String getWp1() {
		return wp1;
	}

	public void setWp1(String wp1) {
		this.wp1 = wp1;
	}

	public String getWp2() {
		return wp2;
	}

	public void setWp2(String wp2) {
		this.wp2 = wp2;
	}

	public String getFp1() {
		return fp1;
	}

	public void setFp1(String fp1) {
		this.fp1 = fp1;
	}

	public String getFp2() {
		return fp2;
	}

	public void setFp2(String fp2) {
		this.fp2 = fp2;
	}
	
}
